define({
  "name": "YunDun API DOCS",
  "version": "4.0.0",
  "description": "",
  "title": "YunDun API DOCS V4",
  "url": "https://apiv4.yundun.com/V4/",
  "header": {
    "title": "",
    "filename": ""
  },
  "footer": {
    "title": "",
    "filename": ""
  },
  "order": [
  ],
  "template": {
    "forceLanguage": "zh_cn",
    "withCompare": true,
    "withGenerator": true
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-12-06T03:03:40.884Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
