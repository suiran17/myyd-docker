define({ "api": [
    {
        "url": "order.binddomain",
        "header": {
            "fields": {
                "Header": [
                    {
                        "description": "<p>app_id.</p>",
                        "group": "Header",
                        "type": "String",
                        "field": "X-Auth-App-Id",
                        "optional": false
                    },
                    {
                        "description": "<p>参数签名.</p>",
                        "group": "Header",
                        "type": "String",
                        "field": "X-Auth-Sign",
                        "optional": false
                    }
                ]
            }
        },
        "groupTitle": "订单管理",
        "error": {
            "examples": [
                {
                    "content": "{\n     \"status\": {\n          \"code\"     : 0,\n          \"message\"  : \"操作失败\",\n          \"create_at\": \"2017-01-12 13:50:50\"\n     },\n     \"data\": {}\n}",
                    "title": "请求失败:",
                    "type": "json"
                }
            ]
        },
        "filename": "/data/www/yundun_api_V4/Controller/Api/V4/Order/Order.php",
        "type": "POST|GET",
        "success": {
            "examples": [
                {
                    "content": "{\n    \"status\": {\n        \"code\": 1,\n        \"message\": \"操作成功\",\n        \"create_at\": \"2018-06-26 14:58:42\",\n    },\n    \"data\": []\n}",
                    "title": "请求成功:",
                    "type": "json"
                }
            ]
        },
        "version": "4.0.0",
        "name": "order_bindDomain",
        "group": "订单管理",
        "title": "绑定域名",
        "parameter": {
            "fields": {
                "Parameter": [
                    {
                        "description": "<p>, 用户套餐ID</p>",
                        "group": "Parameter",
                        "type": "Number",
                        "field": "plan_id",
                        "optional": false
                    },
                    {
                        "description": "<p>域名ID, 如: [1, 2, 3]</p>",
                        "group": "Parameter",
                        "type": "Array",
                        "field": "domainids",
                        "optional": false
                    }
                ]
            },
            "examples": [
                {
                    "content": "{\n  \"domainids\": [6243],\n  \"plan_id\": 459\n}",
                    "title": "请求参数示例:",
                    "type": "json"
                }
            ]
        }
    },
    {
        "url": "firewall.policy.sort",
        "header": {
            "fields": {
                "Header": [
                    {
                        "description": "<p>app_id.</p>",
                        "group": "Header",
                        "type": "String",
                        "field": "X-Auth-App-Id",
                        "optional": false
                    },
                    {
                        "description": "<p>参数签名.</p>",
                        "group": "Header",
                        "type": "String",
                        "field": "X-Auth-Sign",
                        "optional": false
                    }
                ]
            }
        },
        "groupTitle": "防火墙管理",
        "error": {
            "examples": [
                {
                    "content": "{\n     \"status\": {\n          \"code\"     : 0,\n          \"message\"  : \"操作失败\",\n          \"create_at\": \"2017-01-12 13:50:50\"\n     },\n     \"data\": {}\n}",
                    "title": "请求失败:",
                    "type": "json"
                }
            ]
        },
        "filename": "/data/www/yundun_api_V4/Controller/Api/V4/Firewall/Firewall.php",
        "type": "POST",
        "success": {
            "examples": [
                {
                    "content": "{\n    \"status\": {\n        \"code\": 1,\n        \"message\": \"操作成功\",\n        \"create_at\": \"2018-08-01 18:24:43\",\n        \"api_time_consuming\": \"6308.76994133毫秒\",\n        \"function_time_consuming\": \"3317.9471492767毫秒\"\n    },\n    \"data\": []\n}",
                    "title": "请求成功:",
                    "type": "json"
                }
            ]
        },
        "version": "4.0.0",
        "name": "PostFirewallPolicySort",
        "group": "防火墙管理",
        "title": "调整策略顺序",
        "parameter": {
            "fields": {
                "Parameter": [
                    {
                        "description": "<p>新的排序, 格式为：{id: index}, id为策略ID， index为行的索引号, 如：{3: 0, 4: 1, 5: 2}</p>",
                        "group": "Parameter",
                        "type": "Object",
                        "field": "new_sorts",
                        "optional": false
                    }
                ]
            },
            "examples": [
                {
                    "content": "{\n\t    \"new_sorts\": {\n\t        3: 0,\n\t        4: 1,\n\t        5: 2,\n\t    }\n}",
                    "title": "请求参数示例:",
                    "type": "json"
                }
            ]
        }
    },
    {
        "url": "firewall.policyGroup.save",
        "header": {
            "fields": {
                "Header": [
                    {
                        "description": "<p>app_id.</p>",
                        "group": "Header",
                        "type": "String",
                        "field": "X-Auth-App-Id",
                        "optional": false
                    },
                    {
                        "description": "<p>参数签名.</p>",
                        "group": "Header",
                        "type": "String",
                        "field": "X-Auth-Sign",
                        "optional": false
                    }
                ]
            }
        },
        "groupTitle": "防火墙管理",
        "error": {
            "examples": [
                {
                    "content": "{\n     \"status\": {\n          \"code\"     : 0,\n          \"message\"  : \"操作失败\",\n          \"create_at\": \"2017-01-12 13:50:50\"\n     },\n     \"data\": {}\n}",
                    "title": "请求失败:",
                    "type": "json"
                }
            ]
        },
        "filename": "/data/www/yundun_api_V4/Controller/Api/V4/Firewall/Firewall.php",
        "type": "POST",
        "success": {
            "examples": [
                {
                    "content": "{\n    \"status\": {\n        \"code\": 1,\n        \"message\": \"操作成功\",\n        \"create_at\": \"2018-07-13 14:48:51\",\n        \"api_time_consuming\": \"1584.1979980469毫秒\",\n        \"function_time_consuming\": \"847.03493118286毫秒\"\n    },\n    \"data\": {\n        \"id\": \"42\"\n    }\n}",
                    "title": "请求成功:",
                    "type": "json"
                }
            ]
        },
        "version": "4.0.0",
        "name": "PostFirewallPolicygroupSave",
        "group": "防火墙管理",
        "title": "保存策略集",
        "parameter": {
            "fields": {
                "Parameter": [
                    {
                        "description": "<p>策略ID, 针对更新</p>",
                        "group": "Parameter",
                        "type": "Number",
                        "field": "id",
                        "optional": false
                    },
                    {
                        "description": "<p>域名ID</p>",
                        "group": "Parameter",
                        "type": "Number",
                        "field": "domain_id",
                        "optional": false
                    },
                    {
                        "defaultValue": "diy",
                        "field": "from",
                        "description": "<p>策略集来源：aR防倒链 zL区域屏蔽 sP源站保护 cc防CC botBot管理 diy自定义</p>",
                        "group": "Parameter",
                        "type": "String",
                        "optional": true
                    },
                    {
                        "description": "<p>备注</p>",
                        "group": "Parameter",
                        "type": "String",
                        "field": "remark",
                        "optional": false
                    },
                    {
                        "description": "<p>名称</p>",
                        "group": "Parameter",
                        "type": "String",
                        "field": "name",
                        "optional": false
                    }
                ]
            },
            "examples": [
                {
                    "content": "{\n\t\"domain_id\": 1,\n\t\"from\": \"diy\",\n\t\"remark\": \"备注\",\n \"name\": \"自定义\"\n}",
                    "title": "请求参数示例:",
                    "type": "json"
                }
            ]
        }
    }
]});